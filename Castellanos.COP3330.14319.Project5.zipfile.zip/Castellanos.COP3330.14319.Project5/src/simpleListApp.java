/*
Name: Alejandro Castellanos
COP 3330C - 14319
Program Objective/Problem: The overall goal of this project is to display the functionality of lists.
This is achieved through creation, printing, sorting, shuffling, and searching the list. Alongside this we are
expected to implement 2 other static methods from the collection class alongside converting to and from an array.

Collections vs Collection - Despite their obvious similarities, there are key differences between Collection and Collections.
For the former, Collection acts as an interface that primarily represents a group of data(namely objects). Collections
seek to bolster this by adding utility. In my codes case, you can see that I bypass a lot of coding logic by applying
the Collections class. The key difference here is that these are static methods, as opposed to what would be a single static
method when using Collection.
*/

import java.util.*;


public class simpleListApp {
    public static void main (String[] args) {
        //Declare our variable for later!
        String nameSearch;
        //initialize our scanner
        Scanner sc = new Scanner(System.in);
        //Request input from our user.
        System.out.println("Please enter 8 names for our list!");
        //Create our list representing an ordered collection
        List<String> namesForList = new ArrayList<>();
        //Begin our For loop to receive 8 inputs for names
        for (int i = 0; i < 8; i++) {
            namesForList.add(sc.next());
            //system confirmation, not necessary!
            System.out.println("Name added!");
        }
        System.out.println("Your List has been created and sorted!");//Input confirmation for user
        System.out.println(namesForList);//Confirmation of the list input by the user

        System.out.println("Your list will now be sorted alphabetically!");
        //Create a quick sorting for our list using Collections
        Collections.sort(namesForList);
        //A print statement for our list
        System.out.println(namesForList);

        //Header for Custom Sort
        System.out.println("Your List has been created and sorted again by Character Length!");
        //Custom Sorting by Character Length using a Comparator, this is an interface for our comparison

        Collections.sort(namesForList, new Comparator<String>() {//Create our quick method for Comparator for our colelction
            @Override
                    public int compare(String o1, String o2) {//create our custom comparison being used
                        return Integer.compare(o1.length(), o2.length());//apply a quick check that Applies ' Integer'
                    }
                });
        System.out.println(namesForList);//output from Compterator Comparison

        System.out.println("We will now Shuffle the list and present it again!");//Header
        Collections.shuffle(namesForList); // Creating a shuffle class
        System.out.println(namesForList); //Print statement for Shuffle Confirmation

        System.out.println("Now we'll reset your list and reverse their order!");//Quick refresh to our first sort
        Collections.sort(namesForList);

        System.out.println("We will now reverse the list and present it again!"); //Header for our new sorting
        Collections.reverse(namesForList);//Apply the reverse to our Alphabetical Order
        System.out.println(namesForList);//Confirm this with the user

        System.out.println("Now lets try and search our list for someone!");
        nameSearch = sc.next();//request our variable from earlier to search
        if(namesForList.contains(nameSearch)) {//from here create an If statement for finding the variable
            System.out.println(nameSearch + " has been found!");
        }
        else{
            System.out.println(nameSearch + " is not in our list!");//and an else statement for not finding the variable!
        }

        System.out.println("Here is the Array of your list being created along with it's Count!");

        //Converting the list to an array
        String [] namesListArray = namesForList.toArray(new String[0]);
        for(String name: namesListArray) {
            System.out.println(name.toString());//print out
        }
        //From here we will provide our count once more after conversion to ensure that the data itself hasn't been
        Arrays.stream(namesListArray).count();//first we get our count
        System.out.println(Arrays.stream(namesListArray).count()+"people are in this list!");//and then print it


    }
}
